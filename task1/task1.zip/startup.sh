#!/bin/bash
# Install cowsay
sudo apt update
sudo apt install cowsay
cowsay Hi! > text.txt